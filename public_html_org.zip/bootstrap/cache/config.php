<?php return array (
  'app' => 
  array (
    'name' => 'Hyiprio',
    'env' => 'local',
    'debug' => true,
    'demo' => false,
    'url' => 'localhost',
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'key' => 'base64:p2eNu5XoxNvsB8//aTJ/T9JPRrGARrx8tJtXgKKingk=',
    'cipher' => 'AES-256-CBC',
    'maintenance' => 
    array (
      'driver' => 'file',
    ),
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'Mckenziearts\\Notify\\LaravelNotifyServiceProvider',
      23 => 'Spatie\\Permission\\PermissionServiceProvider',
      24 => 'Yajra\\DataTables\\DataTablesServiceProvider',
      25 => 'PragmaRX\\Google2FALaravel\\ServiceProvider',
      26 => 'Mews\\Purifier\\PurifierServiceProvider',
      27 => 'charlesassets\\LaravelPerfectMoney\\LaravelPerfectMoneyServiceProvider',
      28 => 'Unicodeveloper\\Paystack\\PaystackServiceProvider',
      29 => 'App\\Providers\\AppServiceProvider',
      30 => 'App\\Providers\\AuthServiceProvider',
      31 => 'App\\Providers\\EventServiceProvider',
      32 => 'App\\Providers\\RouteServiceProvider',
      33 => 'App\\Providers\\ViewServiceProvider',
      34 => 'App\\Providers\\TxnProvider',
      35 => 'App\\Providers\\GatewayServiceProvider',
      36 => 'App\\Providers\\SettingServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'Date' => 'Illuminate\\Support\\Facades\\Date',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Js' => 'Illuminate\\Support\\Js',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'RateLimiter' => 'Illuminate\\Support\\Facades\\RateLimiter',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Vite' => 'Illuminate\\Support\\Facades\\Vite',
      'Txn' => 'App\\Facades\\Txn\\TxnFacade',
      'Google2FA' => 'PragmaRX\\Google2FALaravel\\Facade',
      'Purifier' => 'Mews\\Purifier\\Facades\\Purifier',
      'PerfectMoney' => 'charlesassets\\LaravelPerfectMoney\\PerfectMoney',
      'Paystack' => 'Unicodeveloper\\Paystack\\Facades\\Paystack',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'admin' => 
      array (
        'driver' => 'session',
        'provider' => 'admins',
      ),
      'sanctum' => 
      array (
        'driver' => 'sanctum',
        'provider' => NULL,
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\User',
      ),
      'admins' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\Admin',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
        'throttle' => 60,
      ),
      'admins' => 
      array (
        'provider' => 'admins',
        'table' => 'password_resets',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'host' => 'api-mt1.pusher.com',
          'port' => '443',
          'scheme' => 'https',
          'encrypted' => true,
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'ably' => 
      array (
        'driver' => 'ably',
        'key' => NULL,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
        'lock_connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => '/home/u514176406/domains/gomeek.net/public_html/storage/framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
        'lock_connection' => 'default',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
      'octane' => 
      array (
        'driver' => 'octane',
      ),
    ),
    'prefix' => 'hyiprio_cache_',
  ),
  'coinbase' => 
  array (
    'apiKey' => '8ef6c4ca-f5c7-4717-9d9a-002adf7e7590',
    'apiVersion' => '2018-03-22',
    'webhookSecret' => 'b789f547-8954-4880-89ae-5a0233006647',
    'webhookJobs' => 
    array (
    ),
    'webhookModel' => 'Shakurov\\Coinbase\\Models\\CoinbaseWebhookCall',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'sanctum/csrf-cookie',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'u514176406_Hyiprio',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => 'localhost',
        'port' => '3306',
        'database' => 'u514176406_Hyiprio',
        'username' => 'u514176406_Gomeek',
        'password' => '&|wdx;g7S',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => 'localhost',
        'port' => '3306',
        'database' => 'u514176406_Hyiprio',
        'username' => 'u514176406_Gomeek',
        'password' => '&|wdx;g7S',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'search_path' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => 'localhost',
        'port' => '3306',
        'database' => 'u514176406_Hyiprio',
        'username' => 'u514176406_Gomeek',
        'password' => '&|wdx;g7S',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'hyiprio_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'datatables' => 
  array (
    'search' => 
    array (
      'smart' => true,
      'multi_term' => true,
      'case_insensitive' => true,
      'use_wildcards' => false,
      'starts_with' => false,
    ),
    'index_column' => 'DT_RowIndex',
    'engines' => 
    array (
      'eloquent' => 'Yajra\\DataTables\\EloquentDataTable',
      'query' => 'Yajra\\DataTables\\QueryDataTable',
      'collection' => 'Yajra\\DataTables\\CollectionDataTable',
    ),
    'builders' => 
    array (
    ),
    'nulls_last_sql' => ':column :direction NULLS LAST',
    'error' => NULL,
    'columns' => 
    array (
      'excess' => 
      array (
        0 => 'rn',
        1 => 'row_num',
      ),
      'escape' => '*',
      'raw' => 
      array (
        0 => 'action',
      ),
      'blacklist' => 
      array (
        0 => 'password',
        1 => 'remember_token',
      ),
      'whitelist' => '*',
    ),
    'json' => 
    array (
      'header' => 
      array (
      ),
      'options' => 0,
    ),
    'callback' => 
    array (
      0 => '$',
      1 => '$.',
      2 => 'function',
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => '/home/u514176406/domains/gomeek.net/public_html/storage/app',
        'throw' => false,
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => '/home/u514176406/domains/gomeek.net/public_html/storage/app/public',
        'url' => 'localhost/storage',
        'visibility' => 'public',
        'throw' => false,
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
        'use_path_style_endpoint' => false,
        'throw' => false,
      ),
    ),
    'links' => 
    array (
      '/home/u514176406/domains/gomeek.net/public_html/assets/storage' => '/home/u514176406/domains/gomeek.net/public_html/storage/app/public',
    ),
  ),
  'google2fa' => 
  array (
    'enabled' => true,
    'lifetime' => 0,
    'keep_alive' => true,
    'auth' => 'auth',
    'guard' => '',
    'session_var' => 'google2fa',
    'otp_input' => 'one_time_password',
    'window' => 12,
    'forbid_old_passwords' => true,
    'otp_secret_column' => 'google2fa_secret',
    'view' => 'frontend.auth.two_fa_pin',
    'error_messages' => 
    array (
      'wrong_otp' => 'The \'One Time Password\' typed was wrong.',
      'cannot_be_empty' => 'One Time Password cannot be empty.',
      'unknown' => 'An unknown error has occurred. Please try again.',
    ),
    'throw_exceptions' => true,
    'qrcode_image_backend' => 'imagemagick',
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 65536,
      'threads' => 1,
      'time' => 4,
    ),
  ),
  'laravel_ticket' => 
  array (
    'table_names' => 
    array (
      'tickets' => 'tickets',
      'categories' => 'categories',
      'labels' => 'labels',
      'messages' => 
      array (
        'table' => 'messages',
        'columns' => 
        array (
          'ticket_foreing_id' => 'ticket_id',
        ),
      ),
      'label_ticket' => 
      array (
        'table' => 'label_ticket',
        'columns' => 
        array (
          'label_foreign_id' => 'label_id',
          'ticket_foreign_id' => 'ticket_id',
        ),
      ),
      'category_ticket' => 
      array (
        'table' => 'category_ticket',
        'columns' => 
        array (
          'category_foreign_id' => 'category_id',
          'ticket_foreign_id' => 'ticket_id',
        ),
      ),
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'deprecations' => 
    array (
      'channel' => NULL,
      'trace' => false,
    ),
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => '/home/u514176406/domains/gomeek.net/public_html/storage/logs/laravel.log',
        'level' => 'debug',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => '/home/u514176406/domains/gomeek.net/public_html/storage/logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'debug',
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
          'connectionString' => 'tls://:',
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => '/home/u514176406/domains/gomeek.net/public_html/storage/logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'host' => 'smtp.hostinger.com',
        'port' => 465,
        'encryption' => 'tls',
        'username' => 'support@gomeek.net',
        'password' => 'Gimnadi@123',
        'timeout' => NULL,
        'local_domain' => NULL,
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'mailgun' => 
      array (
        'transport' => 'mailgun',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
          1 => 'log',
        ),
      ),
    ),
    'from' => 
    array (
      'address' => 'support@gomeek.net',
      'name' => 'Gomeek',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => '/home/u514176406/domains/gomeek.net/public_html/resources/views/vendor/mail',
      ),
    ),
  ),
  'notify' => 
  array (
    'theme' => 'light',
    'demo' => true,
    'timeout' => 5000,
    'preset-messages' => 
    array (
      'user-updated' => 
      array (
        'message' => 'The user has been updated successfully.',
        'type' => 'success',
        'model' => 'connect',
        'title' => 'User Updated',
      ),
    ),
  ),
  'paypal' => 
  array (
    'mode' => 'sandbox',
    'sandbox' => 
    array (
      'client_id' => 'AUnfkQ3v2J-d5g-ZEq8l5Oosha8FmAJ3Z9jt71BkD6l-Z3FMIR5FmkYp_6QHwaYx0LvMNvHDsB9Vh84O',
      'client_secret' => 'EJjci35CFj762ut15pn0VWmojEG0GwE68byyHnBq_NoAXXW9mjkjdLFYLfVQwyLs8QAbP1QJAXPl5oAl',
      'app_id' => 'APP-80W284485P519543T',
    ),
    'live' => 
    array (
      'client_id' => '',
      'client_secret' => '',
      'app_id' => '',
    ),
    'payment_action' => 'Sale',
    'currency' => 'USD',
    'notify_url' => '',
    'locale' => 'en_US',
    'validate_ssl' => true,
  ),
  'paystack' => 
  array (
    'publicKey' => 'pk_test_8e60e513e47ba5619ac0888c9fac99f2853641fa',
    'secretKey' => 'sk_test_e521a3c6d1c37897092868e02e0ddba8c3f0aa01',
    'paymentUrl' => 'https://api.paystack.co',
    'merchantEmail' => 'learn2222earn@gmail.com',
  ),
  'perfectmoney' => 
  array (
    'account_id' => '96793260',
    'passphrase' => '77887848a',
    'marchant_id' => 'U36928259',
    'marchant_name' => 'My Company',
    'units' => 'USD',
    'alternate_passphrase' => 'your_alt_passphrase',
    'payment_url' => 'http://example.com/success',
    'payment_url_method' => NULL,
    'nopayment_url' => 'http://example.com/fail',
    'nopayment_url_method' => NULL,
    'status_url' => NULL,
    'suggested_memo' => NULL,
  ),
  'permission' => 
  array (
    'models' => 
    array (
      'permission' => 'Spatie\\Permission\\Models\\Permission',
      'role' => 'Spatie\\Permission\\Models\\Role',
    ),
    'table_names' => 
    array (
      'roles' => 'roles',
      'permissions' => 'permissions',
      'model_has_permissions' => 'model_has_permissions',
      'model_has_roles' => 'model_has_roles',
      'role_has_permissions' => 'role_has_permissions',
    ),
    'column_names' => 
    array (
      'role_pivot_key' => NULL,
      'permission_pivot_key' => NULL,
      'model_morph_key' => 'model_id',
      'team_foreign_key' => 'team_id',
    ),
    'register_permission_check_method' => true,
    'teams' => false,
    'display_permission_in_exception' => false,
    'display_role_in_exception' => false,
    'enable_wildcard_permission' => false,
    'cache' => 
    array (
      'expiration_time' => 
      DateInterval::__set_state(array(
         'y' => 0,
         'm' => 0,
         'd' => 0,
         'h' => 24,
         'i' => 0,
         's' => 0,
         'f' => 0.0,
         'weekday' => 0,
         'weekday_behavior' => 0,
         'first_last_day_of' => 0,
         'invert' => 0,
         'days' => false,
         'special_type' => 0,
         'special_amount' => 0,
         'have_weekday_relative' => 0,
         'have_special_relative' => 0,
      )),
      'key' => 'spatie.permission.cache',
      'store' => 'default',
    ),
  ),
  'purifier' => 
  array (
    'encoding' => 'UTF-8',
    'finalize' => true,
    'ignoreNonStrings' => false,
    'cachePath' => '/home/u514176406/domains/gomeek.net/public_html/storage/app/purifier',
    'cacheFileMode' => 493,
    'settings' => 
    array (
      'default' => 
      array (
        'HTML.Doctype' => 'HTML 4.01 Transitional',
        'HTML.Allowed' => 'h1 , h2 , h3 , h4 , h5 , h6 ,div,b,strong,i,em,u,a[href|title],ul,ol,li,p[style],br,span[style],img[style|class|width|height|alt|src]',
        'CSS.AllowedProperties' => 'font,font-size,font-weight,font-style,font-family,text-decoration,padding-left,color,background-color,text-align,float,width',
        'CSS.MaxImgLength' => NULL,
        'AutoFormat.AutoParagraph' => true,
        'AutoFormat.RemoveEmpty' => true,
        'URI.AllowedSchemes' => 
        array (
          'data' => true,
          'http' => true,
          'https' => true,
        ),
      ),
      'test' => 
      array (
        'Attr.EnableID' => 'true',
      ),
      'youtube' => 
      array (
        'HTML.SafeIframe' => 'true',
        'URI.SafeIframeRegexp' => '%^(http://|https://|//)(www.youtube.com/embed/|player.vimeo.com/video/)%',
      ),
      'custom_definition' => 
      array (
        'id' => 'html5-definitions',
        'rev' => 1,
        'debug' => false,
        'elements' => 
        array (
          0 => 
          array (
            0 => 'section',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
          ),
          1 => 
          array (
            0 => 'nav',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
          ),
          2 => 
          array (
            0 => 'article',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
          ),
          3 => 
          array (
            0 => 'aside',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
          ),
          4 => 
          array (
            0 => 'header',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
          ),
          5 => 
          array (
            0 => 'footer',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
          ),
          6 => 
          array (
            0 => 'address',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
          ),
          7 => 
          array (
            0 => 'hgroup',
            1 => 'Block',
            2 => 'Required: h1 | h2 | h3 | h4 | h5 | h6',
            3 => 'Common',
          ),
          8 => 
          array (
            0 => 'figure',
            1 => 'Block',
            2 => 'Optional: (figcaption, Flow) | (Flow, figcaption) | Flow',
            3 => 'Common',
          ),
          9 => 
          array (
            0 => 'figcaption',
            1 => 'Inline',
            2 => 'Flow',
            3 => 'Common',
          ),
          10 => 
          array (
            0 => 'video',
            1 => 'Block',
            2 => 'Optional: (source, Flow) | (Flow, source) | Flow',
            3 => 'Common',
            4 => 
            array (
              'src' => 'URI',
              'type' => 'Text',
              'width' => 'Length',
              'height' => 'Length',
              'poster' => 'URI',
              'preload' => 'Enum#auto,metadata,none',
              'controls' => 'Bool',
            ),
          ),
          11 => 
          array (
            0 => 'source',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
            4 => 
            array (
              'src' => 'URI',
              'type' => 'Text',
            ),
          ),
          12 => 
          array (
            0 => 's',
            1 => 'Inline',
            2 => 'Inline',
            3 => 'Common',
          ),
          13 => 
          array (
            0 => 'var',
            1 => 'Inline',
            2 => 'Inline',
            3 => 'Common',
          ),
          14 => 
          array (
            0 => 'sub',
            1 => 'Inline',
            2 => 'Inline',
            3 => 'Common',
          ),
          15 => 
          array (
            0 => 'sup',
            1 => 'Inline',
            2 => 'Inline',
            3 => 'Common',
          ),
          16 => 
          array (
            0 => 'mark',
            1 => 'Inline',
            2 => 'Inline',
            3 => 'Common',
          ),
          17 => 
          array (
            0 => 'wbr',
            1 => 'Inline',
            2 => 'Empty',
            3 => 'Core',
          ),
          18 => 
          array (
            0 => 'ins',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
            4 => 
            array (
              'cite' => 'URI',
              'datetime' => 'CDATA',
            ),
          ),
          19 => 
          array (
            0 => 'del',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
            4 => 
            array (
              'cite' => 'URI',
              'datetime' => 'CDATA',
            ),
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            0 => 'iframe',
            1 => 'allowfullscreen',
            2 => 'Bool',
          ),
          1 => 
          array (
            0 => 'table',
            1 => 'height',
            2 => 'Text',
          ),
          2 => 
          array (
            0 => 'td',
            1 => 'border',
            2 => 'Text',
          ),
          3 => 
          array (
            0 => 'th',
            1 => 'border',
            2 => 'Text',
          ),
          4 => 
          array (
            0 => 'tr',
            1 => 'width',
            2 => 'Text',
          ),
          5 => 
          array (
            0 => 'tr',
            1 => 'height',
            2 => 'Text',
          ),
          6 => 
          array (
            0 => 'tr',
            1 => 'border',
            2 => 'Text',
          ),
        ),
      ),
      'custom_attributes' => 
      array (
        0 => 
        array (
          0 => 'a',
          1 => 'target',
          2 => 'Enum#_blank,_self,_target,_top',
        ),
      ),
      'custom_elements' => 
      array (
        0 => 
        array (
          0 => 'u',
          1 => 'Inline',
          2 => 'Inline',
          3 => 'Common',
        ),
      ),
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
        'after_commit' => false,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
        'after_commit' => false,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'default',
        'suffix' => NULL,
        'region' => 'us-east-1',
        'after_commit' => false,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
        'after_commit' => false,
      ),
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'sanctum' => 
  array (
    'stateful' => 
    array (
      0 => 'localhost',
      1 => 'localhost:3000',
      2 => '127.0.0.1',
      3 => '127.0.0.1:8000',
      4 => '::1',
      5 => '',
    ),
    'guard' => 
    array (
      0 => 'web',
    ),
    'expiration' => NULL,
    'middleware' => 
    array (
      'verify_csrf_token' => 'App\\Http\\Middleware\\VerifyCsrfToken',
      'encrypt_cookies' => 'App\\Http\\Middleware\\EncryptCookies',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
      'scheme' => 'https',
    ),
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => '/home/u514176406/domains/gomeek.net/public_html/storage/framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'hyiprio_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
  ),
  'setting' => 
  array (
    'global' => 
    array (
      'title' => 'Global Settings',
      'elements' => 
      array (
        0 => 
        array (
          'type' => 'file',
          'data' => 'string',
          'name' => 'site_logo',
          'label' => 'Site Logo',
          'rules' => 'mimes:jpeg,jpg,png|max:1000',
          'value' => 'default/fav.png',
        ),
        1 => 
        array (
          'type' => 'file',
          'data' => 'string',
          'name' => 'site_favicon',
          'label' => 'Site Favicon',
          'rules' => 'mimes:jpeg,jpg,png|max:1000',
          'value' => 'image/logo.png',
        ),
        2 => 
        array (
          'type' => 'file',
          'data' => 'string',
          'name' => 'login_bg',
          'label' => 'Admin Login Cover',
          'rules' => 'mimes:jpeg,jpg,png|max:2000',
          'value' => 'default/auth-bg.jpg',
        ),
        3 => 
        array (
          'type' => 'dropdown',
          'data' => 'string',
          'name' => 'site_currency',
          'label' => 'Site Currency',
          'rules' => 'required',
          'value' => 'USD',
        ),
        4 => 
        array (
          'type' => 'dropdown',
          'data' => 'string',
          'name' => 'site_timezone',
          'label' => 'Site Timezone',
          'rules' => 'required',
          'value' => 'UTC',
        ),
        5 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'currency_symbol',
          'label' => 'Currency Symbol',
          'rules' => 'required',
          'value' => '$',
        ),
        6 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'site_title',
          'label' => 'Site Title',
          'rules' => 'required|min:2|max:50',
          'value' => 'Hyiprio',
        ),
        7 => 
        array (
          'type' => 'email',
          'data' => 'string',
          'name' => 'site_email',
          'label' => 'Site Email',
          'rules' => 'required',
          'value' => 'admin@tdevs.co',
        ),
        8 => 
        array (
          'type' => 'email',
          'data' => 'string',
          'name' => 'support_email',
          'label' => 'Support Email',
          'rules' => 'required',
          'value' => 'support@tdevs.co',
        ),
      ),
    ),
    'permission' => 
    array (
      'title' => 'Permission Settings',
      'elements' => 
      array (
        0 => 
        array (
          'type' => 'checkbox',
          'data' => 'boolean',
          'name' => 'email_verification',
          'label' => 'Email Verification',
          'rules' => 'required',
          'value' => 1,
        ),
        1 => 
        array (
          'type' => 'checkbox',
          'data' => 'boolean',
          'name' => 'kyc_verification',
          'label' => 'KYC Verification',
          'rules' => 'required',
          'value' => 1,
        ),
        2 => 
        array (
          'type' => 'checkbox',
          'data' => 'boolean',
          'name' => 'fa_verification',
          'label' => '2FA Verification',
          'rules' => 'required',
          'value' => 1,
        ),
        3 => 
        array (
          'type' => 'checkbox',
          'data' => 'boolean',
          'name' => 'account_creation',
          'label' => 'Account Creation',
          'rules' => 'required',
          'value' => 1,
        ),
        4 => 
        array (
          'type' => 'checkbox',
          'data' => 'boolean',
          'name' => 'user_deposit',
          'label' => 'User Deposit',
          'rules' => 'required',
          'value' => 1,
        ),
        5 => 
        array (
          'type' => 'checkbox',
          'data' => 'boolean',
          'name' => 'user_withdraw',
          'label' => 'User Withdraw',
          'rules' => 'required',
          'value' => 1,
        ),
        6 => 
        array (
          'type' => 'checkbox',
          'data' => 'boolean',
          'name' => 'transfer_status',
          'label' => 'User Send Money',
          'rules' => 'required',
          'value' => 1,
        ),
        7 => 
        array (
          'type' => 'checkbox',
          'data' => 'boolean',
          'name' => 'sign_up_referral',
          'label' => 'User Referral',
          'rules' => 'required',
          'value' => 1,
        ),
        8 => 
        array (
          'type' => 'checkbox',
          'data' => 'boolean',
          'name' => 'referral_signup_bonus',
          'label' => 'Signup Bonus',
          'rules' => 'required',
          'value' => 1,
        ),
        9 => 
        array (
          'type' => 'checkbox',
          'data' => 'boolean',
          'name' => 'investment_referral_bounty',
          'label' => 'Investment Referral Bounty',
          'rules' => 'required',
          'value' => 1,
        ),
        10 => 
        array (
          'type' => 'checkbox',
          'data' => 'boolean',
          'name' => 'deposit_referral_bounty',
          'label' => 'Deposit Referral Bounty',
          'rules' => 'required',
          'value' => 1,
        ),
        11 => 
        array (
          'type' => 'checkbox',
          'data' => 'boolean',
          'name' => 'site_animation',
          'label' => 'Site Animation',
          'rules' => 'required',
          'value' => 1,
        ),
        12 => 
        array (
          'type' => 'checkbox',
          'data' => 'boolean',
          'name' => 'back_to_top',
          'label' => 'Site Back to Top',
          'rules' => 'required',
          'value' => 1,
        ),
        13 => 
        array (
          'type' => 'checkbox',
          'data' => 'boolean',
          'name' => 'debug_mode',
          'label' => 'Development Mode',
          'rules' => 'required',
          'value' => 0,
        ),
      ),
    ),
    'fee' => 
    array (
      'title' => 'Site Fee, Limit and Bonus Settings',
      'elements' => 
      array (
        0 => 
        array (
          'type' => 'text',
          'data' => 'double',
          'name' => 'min_send',
          'label' => 'Minimum Send Money',
          'rules' => 'required',
          'value' => 1,
        ),
        1 => 
        array (
          'type' => 'text',
          'data' => 'double',
          'name' => 'max_send',
          'label' => 'Maximum Send Money',
          'rules' => 'required',
          'value' => 90000,
        ),
        2 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'send_charge_type',
          'label' => 'Send Money Charge Type',
          'rules' => 'required',
          'value' => 90000,
        ),
        3 => 
        array (
          'type' => 'text',
          'data' => 'double',
          'name' => 'send_charge',
          'label' => 'Send Money Charge',
          'rules' => 'required|regex:/^\\d+(\\.\\d{1,2})?$/',
          'value' => 90000,
        ),
        4 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'wallet_exchange_charge_type',
          'label' => 'Wallet Exchange Charge Type',
          'rules' => 'required',
          'value' => 90000,
        ),
        5 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'wallet_exchange_charge',
          'label' => 'Wallet Exchange Charge',
          'rules' => 'required',
          'value' => 90000,
        ),
        6 => 
        array (
          'type' => 'text',
          'data' => 'double',
          'name' => 'referral_bonus',
          'label' => 'Referral Bonus',
          'rules' => 'required|regex:/^\\d+(\\.\\d{1,2})?$/',
          'value' => 20,
        ),
        7 => 
        array (
          'type' => 'text',
          'data' => 'double',
          'name' => 'signup_bonus',
          'label' => 'Sign Up Bonus',
          'rules' => 'required|regex:/^\\d+(\\.\\d{1,2})?$/',
          'value' => 20,
        ),
      ),
    ),
    'mail' => 
    array (
      'title' => 'Mail Settings',
      'elements' => 
      array (
        0 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'email_from_name',
          'label' => 'Email From Name',
          'rules' => 'required|min:5|max:50',
          'value' => 'Tdevs',
        ),
        1 => 
        array (
          'type' => 'email',
          'data' => 'string',
          'name' => 'email_from_address',
          'label' => 'Email From Address',
          'rules' => 'required|min:5|max:50',
          'value' => 'wd2rasel@gmail.com',
        ),
        2 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'mailing_driver',
          'label' => 'Mailing Driver',
          'rules' => 'required',
          'value' => 'SMTP',
        ),
        3 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'mail_username',
          'label' => 'Mail Username',
          'rules' => 'required',
          'value' => '465',
        ),
        4 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'mail_password',
          'label' => 'Mail Password',
          'rules' => 'required',
          'value' => '0000',
        ),
        5 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'mail_host',
          'label' => 'Mail Host',
          'rules' => 'required',
          'value' => 'mail.tdevs.co',
        ),
        6 => 
        array (
          'type' => 'text',
          'data' => 'integer',
          'name' => 'mail_port',
          'label' => 'Mail Port',
          'rules' => 'required',
          'value' => '465',
        ),
        7 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'mail_secure',
          'label' => 'Mail Secure',
          'rules' => 'required',
          'value' => 'ssl',
        ),
      ),
    ),
    'site_maintenance' => 
    array (
      'title' => 'Site Maintenance',
      'elements' => 
      array (
        0 => 
        array (
          'type' => 'checkbox',
          'data' => 'boolean',
          'name' => 'maintenance_mode',
          'label' => 'Maintenance Mode',
          'rules' => 'required',
          'value' => 1,
        ),
        1 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'secret_key',
          'label' => 'Secret Key',
          'rules' => 'required',
          'value' => 'secret',
        ),
        2 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'maintenance_title',
          'label' => 'Title',
          'rules' => 'required',
          'value' => 'Site is not under maintenance',
        ),
        3 => 
        array (
          'type' => 'textarea',
          'data' => 'string',
          'name' => 'maintenance_text',
          'label' => 'Maintenance Text',
          'rules' => 'required|max:500',
          'value' => 'Sorry for interrupt! Site will live soon.',
        ),
      ),
    ),
    'gdpr' => 
    array (
      'title' => 'GDPR Settings',
      'elements' => 
      array (
        0 => 
        array (
          'type' => 'checkbox',
          'data' => 'boolean',
          'name' => 'gdpr_status',
          'label' => 'GDPR Status',
          'rules' => 'required',
          'value' => 1,
        ),
        1 => 
        array (
          'type' => 'textarea',
          'data' => 'string',
          'name' => 'gdpr_text',
          'label' => 'GDPR Text',
          'rules' => 'required|max:500',
          'value' => 'Please allow us to collect data about how you use our website. We will use it to improve our website, make your browsing experience and our business decisions better. Learn more',
        ),
        2 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'gdpr_button_label',
          'label' => 'Button Label',
          'rules' => 'required|max:500',
          'value' => 'Learn More',
        ),
        3 => 
        array (
          'type' => 'text',
          'data' => 'string',
          'name' => 'gdpr_button_url',
          'label' => 'Button URL',
          'rules' => 'required|max:500',
          'value' => '/privacy-policy',
        ),
      ),
    ),
  ),
  'translation' => 
  array (
    'driver' => 'file',
    'route_group_config' => 
    array (
      'middleware' => 
      array (
        0 => 'web',
        1 => 'auth:admin',
      ),
    ),
    'translation_methods' => 
    array (
      0 => 'trans',
      1 => '__',
    ),
    'scan_paths' => 
    array (
      0 => '/home/u514176406/domains/gomeek.net/public_html/app',
      1 => '/home/u514176406/domains/gomeek.net/public_html/resources',
    ),
    'ui_url' => 'language',
    'database' => 
    array (
      'connection' => '',
      'languages_table' => 'languages',
      'translations_table' => 'translations',
    ),
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => '/home/u514176406/domains/gomeek.net/public_html/resources/views',
    ),
    'compiled' => '/home/u514176406/domains/gomeek.net/public_html/storage/framework/views',
  ),
  'mollie' => 
  array (
    'key' => 'test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
