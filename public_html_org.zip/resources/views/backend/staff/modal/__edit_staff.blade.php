<div
    class="modal fade"
    id="editModal"
    tabindex="-1"
    aria-labelledby="editScheduleModalLabel"
    aria-hidden="true"
>
    <div class="modal-dialog modal-md modal-dialog-centered">
        <div class="modal-content site-table-modal">
            <div class="modal-body popup-body">
                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                ></button>
                <div class="popup-body-text" id="edit-staff-body">

                </div>
            </div>
        </div>
    </div>
</div>
